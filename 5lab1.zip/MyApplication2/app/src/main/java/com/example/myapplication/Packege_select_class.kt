package com.example.myapplication


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest

class Packege_select_class : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tours_package_act)
        val recyclerview = findViewById<RecyclerView>(R.id.cal)
        recyclerview.layoutManager = LinearLayoutManager(this)
        val data = ArrayList<ExampleItem>()
        for (i in 1..20) {
            data.add(ExampleItem("item " + i))
        }
        val adapter = CustomAdapter(data)
        recyclerview.adapter = adapter
        val client = createSupabaseClient(
            supabaseUrl = "https://dvwtuhfnsqzahfomxwvf.supabase.co",
            supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR2d3R1aGZuc3F6YWhmb214d3ZmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDM0MDE1MDUsImV4cCI6MjAxODk3NzUwNX0.MwAvGa9cma3_NFE8Vlm6thDmxEb00kBOkqZFdeyMb7E"
        ) {
            install(Postgrest)
            install(Auth)
        }
    }
}