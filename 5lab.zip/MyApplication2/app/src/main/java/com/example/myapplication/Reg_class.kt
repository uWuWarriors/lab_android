package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch

class Reg_class : AppCompatActivity() {
    var mail: String? = null
    var name: String? = null
    var adress_p: String? = null
    var pass: String? = null
    var passP: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.reg_act)
        val name_edit = findViewById(R.id.name_edit) as EditText
        val email_edit = findViewById(R.id.email_edit) as EditText
        val password_edit = findViewById(R.id.password_edit) as EditText
        val password_editP = findViewById(R.id.password_editP) as EditText
        val btnLog = findViewById(R.id.btn_log_1) as Button
        val btnReg = findViewById(R.id.btn_reg_1) as Button
        val client = createSupabaseClient(
            supabaseUrl = "https://dvwtuhfnsqzahfomxwvf.supabase.co",
            supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR2d3R1aGZuc3F6YWhmb214d3ZmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDM0MDE1MDUsImV4cCI6MjAxODk3NzUwNX0.MwAvGa9cma3_NFE8Vlm6thDmxEb00kBOkqZFdeyMb7E"
        ) {
            install(Postgrest)
            install(Auth) {
                alwaysAutoRefresh = false
                autoLoadFromStorage = false
            }
        }

        email_edit.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    email_edit.error = null
                    btnReg.isEnabled = true
                }else{
                    email_edit.error = "Введите E-mail."
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                mail= email_edit.text.toString()
            }
        })
        name_edit.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){
                        name_edit.error = null
                        btnReg.isEnabled = true
                    }else{
                        name_edit.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                name = name_edit.text.toString()
            }
        })
        password_edit.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){

                        password_edit.error = null
                    }else{
                        password_edit.error = "Нужно ввести имя пользователя."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                pass = password_edit.text.toString()

            }
        })
        password_editP.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){

                        password_edit.error = null
                    }else{
                        password_edit.error = "Нужно ввести имя пользователя."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                passP = password_edit.text.toString()
                password_edit.error = "Пароли не совподают"
                password_editP.error = "Пароли не совподают"
            }
        })
        btnReg.setOnClickListener(object : View.OnClickListener{
            override fun onClick(view: View?) {
                if(pass.equals(passP) ){
                    lifecycleScope.launch {
                        val user = client.auth.signUpWith(Email) {
                            email = mail.toString()
                            password = pass.toString()
                        }
                        val user_id = client.auth.retrieveUserForCurrentSession(updateSession = true)
                        var profile = profile(user_id.id.toString(),username=name.toString())
                        client.postgrest["profile"].insert(profile)
                    }
                }else{

                }
                }

               /* val intent1 = Intent(this@Reg_class, address_class::class.java)
                intent.putExtra("name", name)
                startActivity(intent1)*/

               //Переход на след. страницу
               /* val intent = Intent(applicationContext, PIN_reg_class::class.java)
                startActivity(intent)*/
        })
        btnLog.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
              val intent = Intent(applicationContext, MainActivity::class.java)
                startActivity(intent)
            }
        })
    }
}
@kotlinx.serialization.Serializable
data class profile(var id: String = "", var username: String ="", var adress: String = "")
