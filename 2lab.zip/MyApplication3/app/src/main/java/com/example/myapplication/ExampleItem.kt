package com.example.myapplication

data class ExampleItem(val image: Int, val capital: String, val country: String)