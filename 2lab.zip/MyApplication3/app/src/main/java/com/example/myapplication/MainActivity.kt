package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tours_package_act)
        val recyclerview = findViewById<RecyclerView>(R.id.cal)


        recyclerview.layoutManager = LinearLayoutManager(this)


        val data = ArrayList<ExampleItem>()



            data.add(ExampleItem(image = R.drawable.maxresdefault,"Бразилия", "Бразилиа"))
        data.add(ExampleItem(image = R.drawable.argentina,"Аргентина", "Буэнос-Айрес"))
        data.add(ExampleItem(image = R.drawable.colm,"Колумбия", "Богота"))
        data.add(ExampleItem(image = R.drawable.flag,"Уругвай", "Монтевидео"))
        data.add(ExampleItem(image = R.drawable.asdf,"Чили", "Сантьяго"))


        val adapter = CustomAdapter(data)


        recyclerview.adapter = adapter
    }
}